import sys
args = sys.argv
count = 0
for command in args:
    print (command)
    count+=1
print ("Total number of arguments:",count)
input("Thanks")